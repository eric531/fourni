<?php $__env->startSection('content'); ?>

<!-- main content start -->
<div id="page-wrapper">
    <div class="main-page">
        <div class="row-one">
            <div class="col-md-4 widget">
                <div class="stats-left">
                    <h5>NOMBRE</h5>
                    <h4>FOURNISSEURS AGRÉÉS</h4>
                </div>
                <div class="stats-right">
                    <label><?php echo e($fourn_agree); ?></label>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="col-md-4 widget states-mdl">
                <div class="stats-left">
                    <h5>NOMBRE</h5>
                    <h4>FOURNISSEURS PROSPECTS</h4>
                </div>
                <div class="stats-right">
                    <label><?php echo e($fourn_draft); ?></label>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="col-md-4 widget states-last">
                <div class="stats-left">
                    <h5>NOMBRE DE</h5>
                    <h4>FOURNISSEURS BLACKLISTÉS</h4>
                </div>
                <div class="stats-right">
                    <label><?php echo e($fourn_blacklist); ?></label>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="clearfix"> </div>
        </div>

        <div class="tables">
            <div class="table-responsive bs-example widget-shadow">
                <h4>Liste des fournisseurs</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>NOM ENTREPRISE</th>
                            <th>DOMAINE</th>
                            <th>CONTACTS</th>
                            <th>E-MAIL</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fourni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($fourni->entreprise); ?></td>
                            <td><?php echo e($fourni->domaine_activites_1); ?></td>
                            <td><?php echo e($fourni->mobile); ?></td>
                            <td><?php echo e($fourni->email); ?></td>
                            <td>
                                <form action="<?php echo e(route('blacklist_set')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($fourni->id); ?>">
                                    <button type="submit" class="btn btn-primary">Liste noire</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" style="color: red;">Aucun fournisseur enregistré</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sneezy/Documents/GitHub/fourni/resources/views/dashboard.blade.php ENDPATH**/ ?>