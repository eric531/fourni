<?php $__env->startSection('content'); ?>
<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h4 class="text-blue h4">Entreprises</h4>

						</div>

					</div>
                    <div class="col d-flex justify-content-end align-items-end ">
                       <span class="col text-success success"></span>
                       <span class="col text-danger error"></span>
                    </div>
                    <div class="col d-flex justify-content-end align-items-end ">
                        <button type="button" class="btn btn-primary mb-4" data-toggle="modal" data-target="#exampleModal">
                            Ajouter
                        </button>
                    </div>
                    <?php echo $__env->make('admin.entreprises.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Nom</th>
								<th scope="col">Adresse</th>
                                <th scope="col">Email</th>
								<th scope="col">Telephone</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
                            <?php $__currentLoopData = $entreprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entreprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<th scope="row"><?php echo e($entreprise->id); ?></th>
								<td><?php echo e($entreprise->nom); ?></td>
								<td><?php echo e($entreprise->adresse); ?></td>
                                <td><?php echo e($entreprise->email); ?></td>
                                <td><?php echo e($entreprise->telephone); ?></td>
                                <td>
                                <div class="row ">
                            <button onclick="openModalForEdit(<?php echo e($entreprise->id); ?>)" class="btn btn-warning mr-2"><i class="fa fa-edit"></i></button>
                            <form action="<?php echo e(route('entreprises.destroy',['entreprise'=>$entreprise->id])); ?>" method="post">
                              <?php echo method_field('delete'); ?>
                              <?php echo csrf_field(); ?>
                              <button type="submit"  class="btn btn-danger"><i class="fa fa-trash" ></i></button>
                            </form>


                            </div>


                          </td>
							</tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</tbody>
					</table>
				</div>
                 <!-- Ajouter la pagination -->
    <div class="d-flex justify-content-center">
        <?php echo $entreprises->links(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sneezy/Documents/GitHub/fourni/resources/views/admin/entreprises/entreprises.blade.php ENDPATH**/ ?>