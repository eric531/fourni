<?php $__env->startSection('content'); ?>

<div class="pd-20 card-box mb-30">

<form method="POST" action="<?php echo e(route('entreprises.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
          <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nom de l'entreprise</label>
            <div class="col-sm-12 col-md-10">
              <input class="form-control" type="text" placeholder="Nom de l'entreprise" name="nom" id="nom">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Adresse</label>
            <div class="col-sm-12 col-md-10">
              <input class="form-control" type="text" placeholder="Adresse" name="adresse" id="adresse">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Email</label>
            <div class="col-sm-12 col-md-10">
              <input class="form-control" type="email" placeholder="Email" name="email" id="email">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Telepehone</label>
            <div class="col-sm-12 col-md-10">
              <input class="form-control" type="number" placeholder="Telepehone" name="telephone" id="telephone">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Acheteur</label>
            <div class="col-sm-12 col-md-10">
            <select class="form-control" name="user_id" id="acheteur">
            <?php $__currentLoopData = $acheteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acheteur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($acheteur->id); ?>"><?php echo e($acheteur->username); ?> - <?php echo e($acheteur->username); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
            </div>
          </div>

          <button type="submit" class="btn btn-primary me-2">Envoyer</button>
                    <button class="btn btn-light"><a href="<?php echo e(route('products.index')); ?>">Annuler</a></button>

        </form>



<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sneezy/Documents/GitHub/fourni/resources/views/admin/entreprises/edit_entreprise.blade.php ENDPATH**/ ?>